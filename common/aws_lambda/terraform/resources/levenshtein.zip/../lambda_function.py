from fuzzywuzzy import fuzz

def lambda_handler(event, context):
    data = {}
    data['ratio'] = fuzz.ratio('str1', 'str2')
    return data
