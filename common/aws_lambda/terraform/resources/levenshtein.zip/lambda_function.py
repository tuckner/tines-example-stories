from fuzzywuzzy import fuzz

def lambda_handler(event, context):
    data = {}
    data['str1'] = event['str1']
    data['str2'] = event['str2']
    data['ratio'] = fuzz.ratio(data['str1'], data['str2'])
    return data
